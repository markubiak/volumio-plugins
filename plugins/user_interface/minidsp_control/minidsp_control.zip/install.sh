#!/bin/bash

echo "Installing minidsp control Dependencies"
cd /data/plugins/user_interface/minidsp_control
npm install

#requred to end the plugin install
echo "plugininstallend"
