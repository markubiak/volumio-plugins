#!/bin/bash

# Uninstall dependendencies

echo "Done"
echo "pluginuninstallend"
